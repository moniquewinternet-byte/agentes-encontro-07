# Ideias de agente pra destravar

Pra quando a pessoa não sabe o que criar. Não são receitas fechadas, são faíscas:
o agente dela sai do trabalho real dela, não desta lista. Mostre 3 ou 4 que tenham a
ver com o que a pessoa faz, e pergunte qual chega mais perto da dor dela.

## Pra quem atende cliente (serviço, consultoria, saúde, aula)
- Organizador de atendimento: cola a anotação bagunçada do atendimento e ele devolve
  um resumo limpo + o próximo passo, e guarda numa pasta por cliente.
- Preparador de reunião: antes da conversa, junta o que ficou da última vez e monta uma
  pauta.

## Pra quem cria conteúdo
- Faxineiro de ideias: você joga a bagunça de ideias e ele separa em temas e ganchos.
- Arquivador de posts: organiza os arquivos de post em pastas por tema, renomeando pelo
  conteúdo e não pelo nome do arquivo.

## Pra quem lida com papelada / números
- Organizador de recibos: você sobe os comprovantes e ele monta uma lista por mês.
- Conferente de planilha: compara duas versões e aponta o que mudou.

## Pra qualquer uma (rotina)
- Resumo da semana: junta o que você anotou na semana e devolve um resuminho com o que
  ficou pendente.
- Organizador de arquivos: arruma uma pasta bagunçada em pastas temáticas.

Regra de ouro ao sugerir: o melhor primeiro agente é PEQUENO e resolve UMA dor só. Agente
grande demais trava. Comece por um que dê pra testar na mesma conversa.
